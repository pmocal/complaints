import React from 'react';
import './App.css';

const urlAPI = "http://127.0.0.1:8000";

class App extends React.Component {
  constructor(props) {
    super(props);
	this.handleTokenChange = this.handleTokenChange.bind(this);
	this.state = { token: 0 }
  }
  
  handleTokenChange(token) {
    this.setState({token});
  }
  
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <p>NYCC Complaints</p>
        </header>
        { this.state.token ? <Dashboard onTokenChange={this.handleTokenChange} token={this.state.token}/> : <Login onTokenChange={this.handleTokenChange} token={this.state.token}/> }
      </div>
    );
  }
}

class Login extends React.Component {
  async login(username, password) {
    let response = await fetch(urlAPI + "/login/",
      {
        method: 'POST',
        cache: 'no-cache',
        mode:'cors',
        headers: {
          'Content-Type': 'application/json'
        },
        redirect: 'follow',
        body: JSON.stringify({
          "username": username,
          "password": password
        })
      }
    );
    let responseJson = await response.json();
    if (responseJson != null) {
        this.props.onTokenChange(responseJson["token"]);
    }
  }
  
  render() {
    return (
      <form onSubmit={(e) => { e.preventDefault(); this.login(e.target.elements.username.value, e.target.elements.password.value);}}>
        <p>
          <label>Username   </label>
          <input type="text" id="username"/>
        </p>
        <p>
          <label>Password   </label>
          <input type="password" id="password"/>
        </p>
        <input type="submit" value="Submit"/>
      </form>
    );
  }
}

class Dashboard extends React.Component {
  constructor(props) {
    super(props);
	this.state = { complaints: [], openCases: 0, closedCases: 0, topComplaints: "" }
  }
  async componentDidMount() {
    let response = await fetch(urlAPI + "/api/complaints/",
      {
        method: 'GET',
        cache: 'no-cache',
        mode:'cors',
        headers: {
          'Authorization': 'Token ' + this.props.token
        },
        redirect: 'follow',
      }
    );
    let responseJson = await response.json();
	if (responseJson != null) {
		console.log(responseJson);
      this.setState({complaints: responseJson});
      this.setState({openCases: responseJson.filter(function(el) { return el.closedate == null }).length});
	  this.setState({closedCases: responseJson.filter(function(el) { return el.closedate != null }).length});
	}
	var countPropertyValues = {};
	responseJson.forEach(function(obj) {
	  if (countPropertyValues.hasOwnProperty(obj.complaint_type)) {
	    countPropertyValues[obj.complaint_type]++;
	  } else {
	    countPropertyValues[obj.complaint_type] = 1;
	  }
	});
	var keyValues = [];
	for (var key in countPropertyValues) {
      keyValues.push([ key, countPropertyValues[key] ]);
	}
	keyValues.sort(function compare(kv1, kv2) {
		return kv1[1] - kv2[1]
	});
	var foundNull = false;
	if (keyValues.length > 2) {
		if (keyValues[0][0] == null) {
			foundNull = true;
		} else {
			this.setState({topComplaints: this.state.topComplaints + keyValues[0][0] + ","});
		}
		if (keyValues[1][0] == null) {
			foundNull = true;
		} else {
			this.setState({topComplaints: this.state.topComplaints + keyValues[1][0] + ","});
		}
		if (keyValues[2][0] == null) {
			foundNull = true;
		} else {
			this.setState({topComplaints: this.state.topComplaints + keyValues[2][0]});
		}
	}
	if (foundNull) {
		if (keyValues.length > 3) {
			this.setState({topComplaints: this.state.topComplaints + keyValues[3][0]});
		}
	}
  }
  
  render() {
	return (
      <div>
	    <h1>Complaints</h1>
        <table>
		  {this.state.complaints.map(function (complaint) {
			return(
			  <tr>
			    {Object.values(complaint).map(function (datum) {
				  return (
			        <td>{ datum }</td>
				  );
				})}  
			  </tr>
		    )
		  })}
		</table>
		<h2>Open Cases { this.state.openCases }</h2>
		<h2>Closed Cases { this.state.closedCases }</h2>
		<h2>Top Complaints { this.state.topComplaints }</h2>
        <button className="App-link" onClick={() => { this.props.onTokenChange("");}}>Logout</button>
      </div>
	)
  }
}

export default App;
