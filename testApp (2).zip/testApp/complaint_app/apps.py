from django.apps import AppConfig


class ComplaintAppConfig(AppConfig):
    name = 'complaint_app'
